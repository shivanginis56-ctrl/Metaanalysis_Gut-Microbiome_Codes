# Core Microbiome ML Pipeline 

Code for the machine-learning core microbiome analysis: the autoencoder (AE) core, its robustness evaluation, Random Forest race classification, and the KEGG / FAPROTAX functional annotation shown in Fig. 4 and Fig. 6.

## Environment

- Python 3.13. Install packages with `pip install -r requirements.txt`.
- Create a virtual environment with `python3 -m venv microbiome-ml-env && source microbiome-ml-env/bin/activate`.
- FAPROTAX v1.2.12, included in `input/FAPROTAX_1.2.12/`.
- Internet access for the KEGG REST API ([https://rest.kegg.jp](https://rest.kegg.jp)), used by Step 9.
- The autoencoder trains on Apple MPS if available, otherwise CUDA, otherwise CPU.



## Directory layout

```
code/
├── pipeline/            # scripts
├── input/               # all input files (listed below)
├── requirements.txt
└── PIPELINE.md
```

The scripts read their inputs from the directory that contains `pipeline/`. Copy the input files there before running, then run every command from `code/`:

```bash
cp -R input/. .
```



## Input data (`input/`)


| File                                                    | Description                                                                                            |
| ------------------------------------------------------- | ------------------------------------------------------------------------------------------------------ |
| `Taxonomic_abundance.csv`                               | 4,680 taxa × 7,302 samples, raw read counts (Human Microbiome Compendium)                              |
| `metadata_clean.csv`                                    | 7,302 samples: `sample_id, bioproject, race`                                                           |
| `step3_final_core.csv`                                  | 96-taxon manual (threshold-based) core: `Bioproject, Race, OTU_ID, Genus, Prevalence, Median_RelAbund` |
| `"core micrbiome.csv"`                                  | Manual core in its original per-bioproject layout                                                      |
| `step1_binary_normalised.csv`                           | Taxon × sample presence/absence matrix, used for the prevalence weights                                |
| `ae_core_148.csv`                                       | AE core taxon list (`OTU_ID, Genus, Races`), used for the KEGG group comparison                        |
| `ae_only_56_taxa.csv`                                   | AE-only taxa with global prevalence and mean relative abundance                                        |
| `results_long_random_effect_all_taxa_effect_cutoff.csv` | Differential abundance results table (race pairwise comparisons)                                       |
| `kegg_expanded_cache.csv`                               | KEGG KO/pathway annotations, pre-fetched (see note below)                                              |
| `kegg_pathway_list_cache.csv`                           | KEGG pathway ID → name                                                                                 |
| `FAPROTAX_1.2.12/`                                      | FAPROTAX v1.2.12 (`collapse_table.py`, `FAPROTAX.txt`)                                                 |


> **KEGG cache**: `kegg_expanded_cache.csv` stores the live KEGG REST API responses
> (organism code, pathways and KO list per taxon). Step 8 reuses cached taxa and
> queries only new ones, so the annotation does not depend on repeated API calls.



## Pipeline Steps



### Step 1 — AE Core Scoring (seed = 42)

```bash
python3 -m pipeline.unsupervised_pipeline
```

Trains one prevalence-weighted MSE autoencoder per racial group (African, Asian, Caucasian, Hispanic) and computes a CoreScore for every taxon.

Preprocessing, per race:

1. TSS normalisation.
2. Multiplicative zero replacement (δ = 0.65/D).
3. CLR transformation.
4. Per-feature z-scoring.

Architecture: `4680 → 512 → 128 → 64 → 128 → 512 → 4680`.

- Each hidden layer uses Linear, BatchNorm, LeakyReLU(0.1) and Dropout(0.15).
- Optimiser: Adam (lr = 1e-3, weight decay = 1e-4).
- ReduceLROnPlateau scheduler (patience 10, factor 0.5).
- Early stopping with patience 20, up to 150 epochs.
- The reconstruction loss is weighted by each taxon's global prevalence.

**Output**: `ae_emerged_core.csv` — CoreScore of all 4,680 taxa for each race.

### Step 2 — AE Core Thresholds vs Manual Reference

```bash
python3 -m pipeline.threshold_comparison
```

Applies four CoreScore thresholds to each race's scores and takes the union across races. Each threshold is compared against the 96-taxon manual reference.

**Output**: `threshold_comparison.xlsx` (5 sheets: Summary plus one sheet per threshold).

**Key results (seed = 42)**


| Threshold      | Taxa | Precision | Recall | F1    |
| -------------- | ---- | --------- | ------ | ----- |
| Score > mean   | 70   | 1.000     | 0.729  | 0.843 |
| 95% score mass | 119  | 0.739     | 0.917  | 0.819 |




### Step 3 — Robustness Evaluation (100 runs)

```bash
python3 -m pipeline.robustness_eval
```

Reruns the Weighted MSE AE with seeds 0–99 and evaluates the 95%-mass union core against the manual reference in each run. The script can resume after an interruption.

**Outputs**: `robustness_results.csv`, `robustness_summary.txt`

**Result**: F1 = 0.820 ± 0.004 (range 0.811–0.837).

### Step 4 — Per-Taxon Selection Stability (100 runs)

```bash
python3 -m pipeline.taxa_stability_eval
```

Records which taxa are selected in each of the 100 seeds (95%-mass union).

**Outputs**: `taxa_selection_frequency.csv`, `taxa_stability_summary.txt`

**Result**: 88 of the 96 manual core taxa are selected in all 100 runs; 2 are selected in fewer than half of the runs.

### Step 5 — Random Forest Multiclass (Race Prediction)

```bash
python3 -m pipeline.rf_multiclass
```

4-class Random Forest on the 238-taxon pre-filtered matrix (prevalence ≥ 5%):

- 500 trees, `max_features = sqrt`, balanced class weights.
- Evaluated with 5-fold stratified CV and an out-of-bag (OOB) estimate.

**Outputs**: `rf_multiclass_importances.csv`, `rf_multiclass_report.txt`

**Result**: CV accuracy = 0.904 ± 0.006 · OOB accuracy = 0.907 · macro F1 = 0.625 ± 0.010.

### Step 6 — Random Forest Binary Per-Race (RFECV)

```bash
python3 -m pipeline.rf_per_race
```

One-vs-rest Random Forest per race, followed by Recursive Feature Elimination with Cross-Validation (RFECV, ROC-AUC). The RFECV-selected taxa from all races are combined into one union.

**Outputs**: `rf_per_race.csv`, `rf_per_race_summary.csv`

**Result**: 148 discriminative taxa (precision = 0.568, recall = 0.875, F1 = 0.689).

### Step 7 — Count Matrix and Taxon Annotation

```bash
python3 -m pipeline.prep_for_aldex2
```

Exports the 238-taxon pre-filtered count matrix, the sample metadata, and an OTU-to-genus annotation table.

**Outputs**: `aldex2_counts.csv` (238 × 7,302), `aldex2_metadata.csv`, `aldex2_taxon_annotation.csv`

### Step 8 — KEGG Annotation of Core Taxa

```bash
python3 -m pipeline.kegg_expanded
```

Queries KEGG for each taxon in the union of the AE core and the manual core. The groups are Shared, AE-only and Manual-only. For each taxon the script retrieves the best-matching organism code, the KO gene list and the pathway memberships. It then compares functional richness and pathway categories across the three groups.

**Outputs**: `kegg_expanded_cache.csv`, `kegg_expanded_results.csv`, `kegg_group_comparison.csv`, `kegg_enrichment.csv`

### Step 9 — Predicted Pathway Abundance (Tax4Fun2-equivalent)

```bash
python3 -m pipeline.kegg_functional_prediction
```

1. Builds a binary taxon × KO matrix.
2. Multiplies it by the TSS-normalised abundance matrix to get per-sample KO abundances.
3. Aggregates the KOs to KEGG pathways.
4. Averages the pathways per race.

**Outputs**: `kegg_ko_matrix.csv`, `kegg_predicted_pathways.csv`, `kegg_race_pathway_means.csv`

### Step 10 — FAPROTAX Functional Annotation

```bash
python3 -m pipeline.faprotax_analysis
```

Runs FAPROTAX v1.2.12 on the TSS-normalised 238-taxon matrix and on each core subset, then averages each functional group per race.

**Outputs**: `faprotax_functional_profiles.csv`, `faprotax_race_means.csv`, `faprotax_ae_core_means.csv`, `faprotax_manual_core_means.csv`, `faprotax_ae_only_means.csv`

### Step 11 — KEGG + FAPROTAX on the Seed-42 AE Cores

```bash
python3 pipeline/run_functional_correct.py
```

Annotates the 119-taxon and 70-taxon AE cores from Step 2 with KEGG (using the cache) and FAPROTAX.

**Outputs**: `faprotax_ae119_means.csv`, `faprotax_ae70_means.csv`, `faprotax_diff74_means.csv`, plus KEGG and FAPROTAX figures in `reports/figures/`

### Step 12 — Build Final Results Workbook

```bash
python3 pipeline/build_final_xlsx.py
```

**Output**: `final_results_seed42.xlsx` (11 sheets, including `AE_Core_70` and `AE_Core_119`)

### Step 13 — Figure 4: AE Core vs Manual Core

```bash
python3 pipeline/generate_venn.py
```

Draws Venn diagrams of AE-derived vs manual core taxa for each race and for the overall union:

- (a) 95% score mass threshold
- (b) Score > mean threshold

Precision, recall and F1 are shown above each diagram.

**Output**: `reports/figures/fig_venn_ae_cores.{pdf,png}`

### Step 14 — Figure 6: Functional Characterisation

```bash
python3 pipeline/generate_panels.py
```


| Figure panel                                                   | Output file                                          |
| -------------------------------------------------------------- | ---------------------------------------------------- |
| Fig. 6(a) — KO gene richness, AE-only vs Shared vs Manual-only | `reports/figures/panel_6c_kegg_richness.{pdf,png}`   |
| Fig. 6(b) — KEGG pathway categories per taxon group            | `reports/figures/panel_7a_kegg_categories.{pdf,png}` |
| Fig. 6(c) — FAPROTAX functional groups by race                 | `reports/figures/panel_7b_faprotax_race.{pdf,png}`   |




## Full Run (all steps in order)

```bash
source microbiome-ml-env/bin/activate
cp -R input/. .
python3 -m pipeline.unsupervised_pipeline
python3 -m pipeline.threshold_comparison
python3 -m pipeline.robustness_eval
python3 -m pipeline.taxa_stability_eval
python3 -m pipeline.rf_multiclass
python3 -m pipeline.rf_per_race
python3 -m pipeline.prep_for_aldex2
python3 -m pipeline.kegg_expanded
python3 -m pipeline.kegg_functional_prediction
python3 -m pipeline.faprotax_analysis
python3 pipeline/run_functional_correct.py
python3 pipeline/build_final_xlsx.py
python3 pipeline/generate_venn.py
python3 pipeline/generate_panels.py
```



## Pipeline Script Reference


| Script                                   | Purpose                                                              |
| ---------------------------------------- | -------------------------------------------------------------------- |
| `pipeline/config.py`                     | Shared paths and constants (5% prevalence filter, RF/RFECV settings) |
| `pipeline/data_loader.py`                | Loads metadata and the abundance matrix; prevalence pre-filter       |
| `pipeline/transforms.py`                 | CLR transformation (Random Forest input)                             |
| `pipeline/autoencoder.py`                | AE architecture, multiplicative replacement, CLR, CoreScore          |
| `pipeline/autoencoder_v2.py`             | AE training with prevalence-weighted MSE                             |
| `pipeline/comparator.py`                 | Parser for `core micrbiome.csv`                                      |
| `pipeline/feature_selector.py`           | RF ranking and RFECV                                                 |
| `pipeline/unsupervised_pipeline.py`      | **Step 1** — AE CoreScores, seed 42                                  |
| `pipeline/threshold_comparison.py`       | **Step 2** — AE core thresholds vs manual 96                         |
| `pipeline/robustness_eval.py`            | **Step 3** — 100-run robustness                                      |
| `pipeline/taxa_stability_eval.py`        | **Step 4** — 100-run per-taxon selection frequency                   |
| `pipeline/rf_multiclass.py`              | **Step 5** — multiclass RF                                           |
| `pipeline/rf_per_race.py`                | **Step 6** — binary RF + RFECV                                       |
| `pipeline/prep_for_aldex2.py`            | **Step 7** — count matrix and taxon annotation                       |
| `pipeline/kegg_expanded.py`              | **Step 8** — KEGG annotation (with cache)                            |
| `pipeline/kegg_functional_prediction.py` | **Step 9** — predicted pathway abundance                             |
| `pipeline/faprotax_analysis.py`          | **Step 10** — FAPROTAX                                               |
| `pipeline/run_functional_correct.py`     | **Step 11** — KEGG + FAPROTAX on AE-119 / AE-70                      |
| `pipeline/build_final_xlsx.py`           | **Step 12** — results workbook                                       |
| `pipeline/generate_venn.py`              | **Step 13** — Fig. 4                                                 |
| `pipeline/generate_panels.py`            | **Step 14** — Fig. 6(a–c)                                            |




## CoreScore Formula

```
s_i = max(0, μ_CLR,i) / (MSE_i + 1e-8)
```

- `μ_CLR,i` is the mean CLR value of taxon *i* in a race group, taken before standardisation. `s_i > 0` only when this mean is positive, i.e. the taxon is genuinely present.
- `MSE_i` is the per-taxon reconstruction error on the standardised input. A lower error means the taxon is structurally consistent and gets a higher score.
- The score is computed after AE training and is not used during training. It is implemented in `pipeline/autoencoder.py` (`importance_clr_weighted_mse`).

